# Source code web kasir toko roti CRUD PHP MySQL 
Teknologi 
- PHP
- CSS
- MySQL/MariaDB

User Login 
1. Akun admin 
- username : admin
- password : 123

2. Akun kasir
- username : petugas
- password : 321